import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../first-screen/data-service.service';

@Component({
  selector: 'app-final-screen',
  templateUrl: './final-screen.component.html',
  styleUrls: ['./final-screen.component.css']
})
export class FinalScreenComponent implements OnInit {
 
  
  constructor(private DataService: DataServiceService) { }
    
  ngOnInit() :void {
   
  }

}






  
