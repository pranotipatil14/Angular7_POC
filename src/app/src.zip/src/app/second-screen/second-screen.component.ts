import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataServiceService } from '../first-screen/data-service.service';


@Component({
  selector: 'app-second-screen',
  templateUrl: './second-screen.component.html',
  styleUrls: ['./second-screen.component.css']
})

export class SecondScreenComponent implements OnInit {

  AccountInfo: FormGroup;
  
  submitted = false;

  constructor(private DataService: DataServiceService,
    private formBuilder: FormBuilder,
    private router: Router) { }

  ngOnInit() {

    this.AccountInfo = this.formBuilder.group({
      IBANNumber: ['', [Validators.required, Validators.pattern(/^[BE]{2}[0-9]{2}(?:[/]?[0-9]{4}){3}?$/)]],
      Amount: ['', [Validators.required,Validators.pattern(/^\d{1,6}(\.\d{1,2})?$/)]],
      
    });
  }
  

  get f() { return this.AccountInfo.controls; }
  

  onSubmit() {
    this.submitted = true;

    if (this.AccountInfo.invalid) {
      return;
    }
    this.DataService.customerData.IBANNumber = this.AccountInfo.value.IBANNumber;
    this.DataService.customerData.Amount = this.AccountInfo.value.Amount;
    this.router.navigate(['./final-screen']);
  }

  onReset() {
    this.submitted = false;
    this.AccountInfo.reset();
    this.router.navigate(['/']);
  }

}
