import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataServiceService } from './data-service.service';

@Component({
  selector: 'app-first-screen',
  templateUrl: './first-screen.component.html',
  styleUrls: ['./first-screen.component.css']
})


export class FirstScreenComponent implements OnInit {
  Inputfield: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder,
                private router: Router,
                private DataService: DataServiceService) { }

  ngOnInit() {

    this.Inputfield = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
    });
  }

  get f() { return this.Inputfield.controls; }


  onSubmit() {
    this.submitted = true;

    //  if field  is empty 
    if (this.Inputfield.invalid) {
      return;

    }
    
  this.DataService.customerData.firstname = this.Inputfield.value.firstName;
  this.DataService.customerData.lastname = this.Inputfield.value.lastName;
  this.router.navigate(['/second-screen']);
}

onReset() {
  this.submitted = false;
  this.Inputfield.reset();
}
}

  




